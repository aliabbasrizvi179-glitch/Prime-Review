import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function AdminDashboard() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('dashboard');

  // Redirect if not authenticated or not an admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || (user as any)?.role !== 'admin')) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: stats } = useQuery({
    queryKey: ["/api/admin/stats"],
    enabled: !!(user as any)?.id && (user as any)?.role === 'admin',
  });

  const { data: pendingReviews = [] } = useQuery({
    queryKey: ["/api/reviews/pending"],
    enabled: !!(user as any)?.id && (user as any)?.role === 'admin',
  });

  const { data: sliders = [] } = useQuery({
    queryKey: ["/api/sliders"],
  });

  // Additional admin queries
  const { data: allUsers = [] } = useQuery({
    queryKey: ["/api/admin/users"],
    enabled: !!(user as any)?.id && (user as any)?.role === 'admin',
  });

  const { data: allBrands = [] } = useQuery({
    queryKey: ["/api/admin/brands"],
    enabled: !!(user as any)?.id && (user as any)?.role === 'admin',
  });

  const { data: allCampaigns = [] } = useQuery({
    queryKey: ["/api/admin/campaigns"],
    enabled: !!(user as any)?.id && (user as any)?.role === 'admin',
  });

  const { data: allPayments = [] } = useQuery({
    queryKey: ["/api/admin/payments"],
    enabled: !!(user as any)?.id && (user as any)?.role === 'admin',
  });

  const { data: systemSettings = {} } = useQuery({
    queryKey: ["/api/admin/settings"],
    enabled: !!(user as any)?.id && (user as any)?.role === 'admin',
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["/api/categories"],
    enabled: !!(user as any)?.id && (user as any)?.role === 'admin',
  });

  const { data: notifications = [] } = useQuery({
    queryKey: ["/api/admin/notifications"],
    enabled: !!(user as any)?.id && (user as any)?.role === 'admin',
  });

  const reviewMutation = useMutation({
    mutationFn: async ({ reviewId, status, adminNotes }: { reviewId: string; status: string; adminNotes?: string }) => {
      await apiRequest("PUT", `/api/reviews/${reviewId}/status`, { status, adminNotes });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Success",
        description: "Review status updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update review status",
        variant: "destructive",
      });
    },
  });

  // User management mutations
  const userMutation = useMutation({
    mutationFn: async ({ userId, action, data }: { userId: string; action: string; data?: any }) => {
      await apiRequest("PUT", `/api/admin/users/${userId}`, { action, ...data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Success",
        description: "User updated successfully",
      });
    },
  });

  // Brand management mutations
  const brandMutation = useMutation({
    mutationFn: async ({ brandId, action, data }: { brandId: string; action: string; data?: any }) => {
      await apiRequest("PUT", `/api/admin/brands/${brandId}`, { action, ...data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/brands"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Success",
        description: "Brand updated successfully",
      });
    },
  });

  // Campaign management mutations
  const campaignMutation = useMutation({
    mutationFn: async ({ campaignId, action, data }: { campaignId: string; action: string; data?: any }) => {
      await apiRequest("PUT", `/api/admin/campaigns/${campaignId}`, { action, ...data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Success",
        description: "Campaign updated successfully",
      });
    },
  });

  // System settings mutations
  const settingsMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("PUT", "/api/admin/settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/settings"] });
      toast({
        title: "Success",
        description: "Settings updated successfully",
      });
    },
  });

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  const handleBackToHome = () => {
    window.location.href = '/';
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.charAt(0) || ""}${lastName?.charAt(0) || ""}`.toUpperCase();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Dashboard Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-primary" data-testid="logo">primereview</h1>
              <span className="text-sm bg-destructive/10 text-destructive px-3 py-1 rounded-full font-medium">Admin Panel</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="sm"
                onClick={handleBackToHome}
                data-testid="button-home"
              >
                <i className="fas fa-home mr-2"></i>
                Home
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full" data-testid="profile-menu-trigger">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={(user as any)?.profileImageUrl} alt={`${(user as any)?.firstName} ${(user as any)?.lastName}`} />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getInitials((user as any)?.firstName, (user as any)?.lastName)}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none" data-testid="profile-name">
                        {(user as any)?.firstName} {(user as any)?.lastName}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground" data-testid="profile-email">
                        {(user as any)?.email}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground capitalize" data-testid="profile-role">
                        Role: {(user as any)?.role}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <a href="/profile" className="cursor-pointer" data-testid="profile-menu-profile">
                      <i className="fas fa-user mr-2 h-4 w-4"></i>
                      <span>Profile Settings</span>
                    </a>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <div className="cursor-default" data-testid="profile-menu-wallet">
                      <i className="fas fa-shield-alt mr-2 h-4 w-4"></i>
                      <span>Admin Access</span>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-red-600" data-testid="profile-menu-logout">
                    <i className="fas fa-sign-out-alt mr-2 h-4 w-4"></i>
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>
      
      <div className="flex">
        {/* Admin Sidebar */}
        <aside className="w-64 bg-card border-r border-border min-h-screen">
          <nav className="p-6">
            <ul className="space-y-2">
              <li><button onClick={() => setActiveTab('dashboard')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'dashboard' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-dashboard">
                <i className="fas fa-tachometer-alt"></i><span>Dashboard</span>
              </button></li>
              <li><button onClick={() => setActiveTab('users')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'users' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-users">
                <i className="fas fa-users"></i><span>User Management</span>
              </button></li>
              <li><button onClick={() => setActiveTab('brands')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'brands' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-brands">
                <i className="fas fa-building"></i><span>Brand Management</span>
              </button></li>
              <li><button onClick={() => setActiveTab('campaigns')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'campaigns' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-campaigns">
                <i className="fas fa-bullhorn"></i><span>Campaign Oversight</span>
              </button></li>
              <li><button onClick={() => setActiveTab('reviews')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'reviews' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-reviews">
                <i className="fas fa-clipboard-check"></i><span>Review Approval</span>
              </button></li>
              <li><button onClick={() => setActiveTab('payments')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'payments' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-payments">
                <i className="fas fa-credit-card"></i><span>Payment Management</span>
              </button></li>
              <li><button onClick={() => setActiveTab('analytics')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'analytics' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-analytics">
                <i className="fas fa-chart-bar"></i><span>Analytics</span>
              </button></li>
              <li><button onClick={() => setActiveTab('content')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'content' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-content">
                <i className="fas fa-sliders-h"></i><span>Content Management</span>
              </button></li>
              <li><button onClick={() => setActiveTab('database')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'database' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-database">
                <i className="fas fa-database"></i><span>Database Control</span>
              </button></li>
              <li><button onClick={() => setActiveTab('settings')} className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors ${
                activeTab === 'settings' ? 'text-primary bg-primary/10' : 'text-muted-foreground hover:text-foreground hover:bg-muted'
              }`} data-testid="nav-settings">
                <i className="fas fa-cog"></i><span>System Settings</span>
              </button></li>
            </ul>
          </nav>
        </aside>
        
        {/* Main Admin Content */}
        <main className="flex-1 p-6">
          {activeTab === 'dashboard' && (
            <>
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-foreground mb-2">Admin Dashboard</h2>
                <p className="text-muted-foreground">Manage your review platform efficiently</p>
              </div>
              
              {/* Admin Stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Total Users</p>
                        <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-users">{(stats as any)?.totalUsers || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-users text-primary text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Active Brands</p>
                        <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-brands">{(stats as any)?.totalBrands || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-building text-accent text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Pending Reviews</p>
                        <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-pending">{(stats as any)?.pendingReviews || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i className="fas fa-clock text-yellow-600 text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Total Revenue</p>
                        <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-revenue">₹{(stats as any)?.totalRevenue || '0'}</p>
                      </div>
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-chart-line text-accent text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Total Reviews</p>
                        <p className="text-2xl font-bold text-foreground" data-testid="admin-stat-total-reviews">{(stats as any)?.totalReviews || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-secondary/50 rounded-lg flex items-center justify-center">
                        <i className="fas fa-star text-primary text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </>
          )}

          {activeTab === 'reviews' && (
            <div className="mb-8">
              <h3 className="text-2xl font-semibold text-foreground mb-6">Pending Review Approvals</h3>
              
              {(pendingReviews as any[]).length === 0 ? (
                <Card>
                  <CardContent className="p-8 text-center">
                    <i className="fas fa-check-circle text-accent text-4xl mb-4"></i>
                    <p className="text-muted-foreground">No pending reviews to approve</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {(pendingReviews as any[]).map((review: any) => (
                    <Card key={review.id} data-testid={`review-approval-${review.id}`}>
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-semibold text-foreground mb-2" data-testid={`review-title-${review.id}`}>{review.title}</h4>
                            <p className="text-muted-foreground text-sm mb-4" data-testid={`review-content-${review.id}`}>{review.content.substring(0, 200)}...</p>
                            <div className="flex items-center space-x-4 text-sm">
                              <span className="text-muted-foreground" data-testid={`review-date-${review.id}`}>
                                {new Date(review.submittedAt).toLocaleDateString()}
                              </span>
                              <span className="flex items-center text-accent">
                                <i className="fas fa-rupee-sign mr-1"></i>
                                <span data-testid={`review-reward-${review.id}`}>₹{review.rewardAmount}</span>
                              </span>
                              <span className="flex items-center text-yellow-600">
                                <i className="fas fa-star mr-1"></i>
                                <span data-testid={`review-rating-${review.id}`}>{review.rating}/5</span>
                              </span>
                            </div>
                          </div>
                          
                          <div className="flex space-x-2 ml-4">
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => reviewMutation.mutate({ reviewId: review.id, status: 'declined' })}
                              disabled={reviewMutation.isPending}
                              data-testid={`button-decline-${review.id}`}
                            >
                              Decline
                            </Button>
                            <Button
                              onClick={() => reviewMutation.mutate({ reviewId: review.id, status: 'approved' })}
                              disabled={reviewMutation.isPending}
                              data-testid={`button-approve-${review.id}`}
                            >
                              Approve
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* User Management */}
          {activeTab === 'users' && (
            <div className="mb-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-semibold text-foreground">User Management</h3>
                <div className="flex space-x-2">
                  <Button data-testid="button-create-user" className="bg-primary hover:bg-primary/90">
                    <i className="fas fa-plus mr-2"></i>Create User
                  </Button>
                  <Button variant="outline" data-testid="button-export-users">
                    <i className="fas fa-download mr-2"></i>Export Users
                  </Button>
                </div>
              </div>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <Input placeholder="Search users..." className="max-w-sm" data-testid="input-search-users" />
                    <Select>
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Filter by role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Roles</SelectItem>
                        <SelectItem value="user">Users</SelectItem>
                        <SelectItem value="brand">Brands</SelectItem>
                        <SelectItem value="admin">Admins</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">User</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Role</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Status</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Joined</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(allUsers as any[]).map((user: any) => (
                          <tr key={user.id} className="border-b border-border hover:bg-muted/50 transition-colors" data-testid={`user-row-${user.id}`}>
                            <td className="py-4 px-4">
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                                  <i className="fas fa-user text-primary"></i>
                                </div>
                                <div>
                                  <p className="font-medium text-foreground" data-testid={`user-name-${user.id}`}>
                                    {user.firstName} {user.lastName}
                                  </p>
                                  <p className="text-sm text-muted-foreground" data-testid={`user-email-${user.id}`}>
                                    {user.email}
                                  </p>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-4">
                              <Badge variant={user.role === 'admin' ? 'destructive' : user.role === 'brand' ? 'default' : 'secondary'}>
                                {user.role}
                              </Badge>
                            </td>
                            <td className="py-4 px-4">
                              <Badge variant={user.status === 'active' ? 'default' : 'secondary'}>
                                {user.status}
                              </Badge>
                            </td>
                            <td className="py-4 px-4 text-sm text-muted-foreground">
                              {new Date(user.createdAt).toLocaleDateString()}
                            </td>
                            <td className="py-4 px-4">
                              <div className="flex space-x-2">
                                <Button variant="outline" size="sm" data-testid={`button-edit-user-${user.id}`}>
                                  Edit
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => userMutation.mutate({ 
                                    userId: user.id, 
                                    action: user.status === 'active' ? 'suspend' : 'activate' 
                                  })}
                                  data-testid={`button-toggle-user-${user.id}`}
                                >
                                  {user.status === 'active' ? 'Suspend' : 'Activate'}
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Brand Management */}
          {activeTab === 'brands' && (
            <div className="mb-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-semibold text-foreground">Brand Management</h3>
                <div className="flex space-x-2">
                  <Button data-testid="button-create-brand" className="bg-primary hover:bg-primary/90">
                    <i className="fas fa-plus mr-2"></i>Create Brand
                  </Button>
                  <Button variant="outline" data-testid="button-pending-brands">
                    <i className="fas fa-clock mr-2"></i>Pending Approvals ({(allBrands as any[]).filter((b: any) => b.status === 'pending').length})
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {(allBrands as any[]).map((brand: any) => (
                  <Card key={brand.id} data-testid={`brand-card-${brand.id}`}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h4 className="font-semibold text-foreground text-lg" data-testid={`brand-name-${brand.id}`}>
                              {brand.firstName} {brand.lastName}
                            </h4>
                            <Badge variant={brand.status === 'approved' ? 'default' : brand.status === 'pending' ? 'secondary' : 'destructive'}>
                              {brand.status}
                            </Badge>
                          </div>
                          <p className="text-muted-foreground text-sm mb-2" data-testid={`brand-email-${brand.id}`}>
                            {brand.email}
                          </p>
                          <div className="flex items-center space-x-4 text-sm">
                            <span className="text-muted-foreground">
                              Campaigns: {brand.campaignCount || 0}
                            </span>
                            <span className="text-muted-foreground">
                              Spent: ₹{brand.totalSpent || 0}
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        {brand.status === 'pending' && (
                          <>
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => brandMutation.mutate({ brandId: brand.id, action: 'reject' })}
                              data-testid={`button-reject-brand-${brand.id}`}
                            >
                              Reject
                            </Button>
                            <Button 
                              size="sm"
                              onClick={() => brandMutation.mutate({ brandId: brand.id, action: 'approve' })}
                              data-testid={`button-approve-brand-${brand.id}`}
                            >
                              Approve
                            </Button>
                          </>
                        )}
                        <Button variant="outline" size="sm" data-testid={`button-view-brand-${brand.id}`}>
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Campaign Oversight */}
          {activeTab === 'campaigns' && (
            <div className="mb-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-semibold text-foreground">Campaign Oversight</h3>
                <div className="flex space-x-2">
                  <Button data-testid="button-create-campaign-admin" className="bg-primary hover:bg-primary/90">
                    <i className="fas fa-plus mr-2"></i>Create Campaign
                  </Button>
                  <Select>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Filter status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Campaigns</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="suspended">Suspended</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Card>
                <CardContent className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Campaign</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Brand</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Status</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Progress</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(allCampaigns as any[]).map((campaign: any) => (
                          <tr key={campaign.id} className="border-b border-border hover:bg-muted/50 transition-colors" data-testid={`campaign-row-${campaign.id}`}>
                            <td className="py-4 px-4">
                              <div>
                                <p className="font-medium text-foreground" data-testid={`campaign-title-${campaign.id}`}>
                                  {campaign.title}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  ₹{campaign.rewardAmount} per review
                                </p>
                              </div>
                            </td>
                            <td className="py-4 px-4">
                              <p className="text-foreground">{campaign.brandName}</p>
                            </td>
                            <td className="py-4 px-4">
                              <Badge variant={campaign.status === 'active' ? 'default' : 'secondary'}>
                                {campaign.status}
                              </Badge>
                            </td>
                            <td className="py-4 px-4">
                              <div className="text-sm">
                                <span className="font-medium">{campaign.completedReviews}</span>
                                <span className="text-muted-foreground">/ {campaign.totalReviewsNeeded}</span>
                              </div>
                            </td>
                            <td className="py-4 px-4">
                              <div className="flex space-x-2">
                                <Button variant="outline" size="sm" data-testid={`button-view-campaign-${campaign.id}`}>
                                  View
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => campaignMutation.mutate({ 
                                    campaignId: campaign.id, 
                                    action: campaign.status === 'active' ? 'suspend' : 'activate' 
                                  })}
                                  data-testid={`button-toggle-campaign-${campaign.id}`}
                                >
                                  {campaign.status === 'active' ? 'Suspend' : 'Activate'}
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Payment Management */}
          {activeTab === 'payments' && (
            <div className="mb-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-semibold text-foreground">Payment Management</h3>
                <div className="flex space-x-2">
                  <Button variant="outline" data-testid="button-pending-withdrawals">
                    <i className="fas fa-clock mr-2"></i>Pending Withdrawals
                  </Button>
                  <Button data-testid="button-payment-report">
                    <i className="fas fa-chart-line mr-2"></i>Generate Report
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Total Processed</p>
                        <p className="text-2xl font-bold text-foreground">₹{(stats as any)?.totalPayments || '0'}</p>
                      </div>
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-credit-card text-accent text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Pending</p>
                        <p className="text-2xl font-bold text-foreground">₹{(stats as any)?.pendingPayments || '0'}</p>
                      </div>
                      <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i className="fas fa-clock text-yellow-600 text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">This Month</p>
                        <p className="text-2xl font-bold text-foreground">₹{(stats as any)?.monthlyPayments || '0'}</p>
                      </div>
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-calendar text-primary text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Disputes</p>
                        <p className="text-2xl font-bold text-foreground">{(stats as any)?.paymentDisputes || 0}</p>
                      </div>
                      <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-exclamation-triangle text-destructive text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardContent className="p-6">
                  <h4 className="font-semibold text-foreground mb-4">Recent Transactions</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Transaction</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">User</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Amount</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Status</th>
                          <th className="text-left py-3 px-4 text-muted-foreground font-medium">Date</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(allPayments as any[]).slice(0, 10).map((payment: any) => (
                          <tr key={payment.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                            <td className="py-4 px-4">
                              <div>
                                <p className="font-medium text-foreground">{payment.type}</p>
                                <p className="text-sm text-muted-foreground">#{payment.id.substring(0, 8)}</p>
                              </div>
                            </td>
                            <td className="py-4 px-4">
                              <p className="text-foreground">{payment.userName}</p>
                            </td>
                            <td className="py-4 px-4">
                              <p className="font-medium text-foreground">₹{payment.amount}</p>
                            </td>
                            <td className="py-4 px-4">
                              <Badge variant={payment.status === 'completed' ? 'default' : 'secondary'}>
                                {payment.status}
                              </Badge>
                            </td>
                            <td className="py-4 px-4 text-sm text-muted-foreground">
                              {new Date(payment.createdAt).toLocaleDateString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Analytics */}
          {activeTab === 'analytics' && (
            <div className="mb-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-semibold text-foreground">Platform Analytics</h3>
                <Select>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Time period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7days">Last 7 days</SelectItem>
                    <SelectItem value="30days">Last 30 days</SelectItem>
                    <SelectItem value="90days">Last 90 days</SelectItem>
                    <SelectItem value="1year">Last year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Growth Rate</p>
                        <p className="text-2xl font-bold text-foreground">+12.5%</p>
                      </div>
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-chart-line text-accent text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Conversion Rate</p>
                        <p className="text-2xl font-bold text-foreground">84.2%</p>
                      </div>
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-percentage text-primary text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Avg. Review Quality</p>
                        <p className="text-2xl font-bold text-foreground">4.6/5</p>
                      </div>
                      <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                        <i className="fas fa-star text-yellow-600 text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-muted-foreground text-sm">Platform Score</p>
                        <p className="text-2xl font-bold text-foreground">9.2/10</p>
                      </div>
                      <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                        <i className="fas fa-trophy text-accent text-lg"></i>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <h4 className="font-semibold text-foreground mb-4">Top Performing Categories</h4>
                    <div className="space-y-4">
                      {['Electronics', 'Fashion', 'Home & Garden', 'Beauty', 'Sports'].map((category, index) => (
                        <div key={category} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center text-sm font-medium text-primary">
                              {index + 1}
                            </div>
                            <span className="text-foreground">{category}</span>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-foreground">{Math.floor(Math.random() * 500) + 100} reviews</p>
                            <p className="text-sm text-muted-foreground">₹{Math.floor(Math.random() * 50000) + 10000}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <h4 className="font-semibold text-foreground mb-4">Recent Activity</h4>
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-accent/10 rounded-full flex items-center justify-center">
                          <i className="fas fa-user-plus text-accent text-sm"></i>
                        </div>
                        <div>
                          <p className="text-foreground">5 new users registered</p>
                          <p className="text-sm text-muted-foreground">2 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                          <i className="fas fa-star text-primary text-sm"></i>
                        </div>
                        <div>
                          <p className="text-foreground">12 reviews approved</p>
                          <p className="text-sm text-muted-foreground">4 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                          <i className="fas fa-building text-yellow-600 text-sm"></i>
                        </div>
                        <div>
                          <p className="text-foreground">3 brands approved</p>
                          <p className="text-sm text-muted-foreground">6 hours ago</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {/* Content Management */}
          {activeTab === 'content' && (
            <div className="mb-8">
              <h3 className="text-2xl font-semibold text-foreground mb-6">Content Management</h3>
              
              <Tabs defaultValue="sliders" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="sliders">Homepage Sliders</TabsTrigger>
                  <TabsTrigger value="announcements">Announcements</TabsTrigger>
                  <TabsTrigger value="categories">Categories</TabsTrigger>
                  <TabsTrigger value="templates">Templates</TabsTrigger>
                </TabsList>
                
                <TabsContent value="sliders" className="mt-6">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {(sliders as any[]).map((slider: any, index: number) => (
                      <Card key={slider.id} data-testid={`slider-${index + 1}`}>
                        <CardContent className="p-6">
                          <div className="flex justify-between items-center mb-4">
                            <h4 className="font-medium text-foreground">Slider {slider.position}</h4>
                            <Button variant="ghost" size="sm" data-testid={`button-edit-slider-${slider.position}`}>
                              Edit
                            </Button>
                          </div>
                          <div className="h-32 bg-gradient-to-r from-primary to-primary/80 rounded-lg mb-4 flex items-center justify-center">
                            <span className="text-white font-medium">{slider.title}</span>
                          </div>
                          <div className="space-y-2">
                            <Input
                              placeholder="Slider title"
                              defaultValue={slider.title}
                              data-testid={`input-slider-title-${slider.position}`}
                            />
                            <Textarea
                              placeholder="Slider description"
                              defaultValue={slider.description}
                              className="h-20"
                              data-testid={`input-slider-description-${slider.position}`}
                            />
                            <Input
                              placeholder="Button link"
                              defaultValue={slider.buttonLink}
                              data-testid={`input-slider-link-${slider.position}`}
                            />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                  
                  <div className="mt-6 text-center">
                    <Button data-testid="button-update-sliders">
                      Update Sliders
                    </Button>
                  </div>
                </TabsContent>
                
                <TabsContent value="announcements" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-center mb-4">
                        <h4 className="font-semibold text-foreground">Platform Announcements</h4>
                        <Button data-testid="button-new-announcement">
                          <i className="fas fa-plus mr-2"></i>New Announcement
                        </Button>
                      </div>
                      <div className="space-y-4">
                        <div className="border border-border rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <h5 className="font-medium text-foreground">System Maintenance Notice</h5>
                            <Badge variant="secondary">Active</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            Scheduled maintenance on Sunday, 2:00 AM - 4:00 AM
                          </p>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">Edit</Button>
                            <Button variant="outline" size="sm">Disable</Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="categories" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-center mb-4">
                        <h4 className="font-semibold text-foreground">Review Categories</h4>
                        <div className="flex space-x-2">
                          <Button data-testid="button-new-category" className="bg-primary hover:bg-primary/90">
                            <i className="fas fa-plus mr-2"></i>Add Category
                          </Button>
                          <Button variant="outline" data-testid="button-manage-categories">
                            <i className="fas fa-cog mr-2"></i>Manage All
                          </Button>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {['Electronics', 'Fashion', 'Home & Garden', 'Beauty', 'Sports', 'Books'].map((category) => (
                          <div key={category} className="border border-border rounded-lg p-4">
                            <div className="flex justify-between items-center">
                              <div>
                                <h5 className="font-medium text-foreground">{category}</h5>
                                <p className="text-sm text-muted-foreground">₹{Math.floor(Math.random() * 100) + 50} - ₹{Math.floor(Math.random() * 100) + 150}</p>
                              </div>
                              <Button variant="outline" size="sm">Edit</Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="templates" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h4 className="font-semibold text-foreground mb-4">Email Templates</h4>
                      <div className="space-y-4">
                        {['Welcome Email', 'Review Approved', 'Payment Processed', 'Campaign Ended'].map((template) => (
                          <div key={template} className="border border-border rounded-lg p-4">
                            <div className="flex justify-between items-center">
                              <div>
                                <h5 className="font-medium text-foreground">{template}</h5>
                                <p className="text-sm text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>
                              </div>
                              <Button variant="outline" size="sm">Edit Template</Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}

          {/* Database Control */}
          {activeTab === 'database' && (
            <div className="mb-8">
              <h3 className="text-2xl font-semibold text-foreground mb-6">Database Control Panel</h3>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
                {/* Users Database Control */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-foreground flex items-center">
                        <i className="fas fa-users mr-2 text-primary"></i>
                        Users Table
                      </h4>
                      <Badge variant="secondary">{(allUsers as any[]).length} records</Badge>
                    </div>
                    <div className="space-y-3">
                      <Button className="w-full" data-testid="button-create-user-db">
                        <i className="fas fa-plus mr-2"></i>Create New User
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-view-users-db">
                        <i className="fas fa-eye mr-2"></i>View All Users
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-edit-users-db">
                        <i className="fas fa-edit mr-2"></i>Bulk Edit Users
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Campaigns Database Control */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-foreground flex items-center">
                        <i className="fas fa-bullhorn mr-2 text-primary"></i>
                        Campaigns Table
                      </h4>
                      <Badge variant="secondary">{(allCampaigns as any[]).length} records</Badge>
                    </div>
                    <div className="space-y-3">
                      <Button className="w-full" data-testid="button-create-campaign-db">
                        <i className="fas fa-plus mr-2"></i>Create New Campaign
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-view-campaigns-db">
                        <i className="fas fa-eye mr-2"></i>View All Campaigns
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-edit-campaigns-db">
                        <i className="fas fa-edit mr-2"></i>Bulk Edit Campaigns
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Reviews Database Control */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-foreground flex items-center">
                        <i className="fas fa-star mr-2 text-primary"></i>
                        Reviews Table
                      </h4>
                      <Badge variant="secondary">{(pendingReviews as any[]).length} records</Badge>
                    </div>
                    <div className="space-y-3">
                      <Button className="w-full" data-testid="button-create-review-db">
                        <i className="fas fa-plus mr-2"></i>Create New Review
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-view-reviews-db">
                        <i className="fas fa-eye mr-2"></i>View All Reviews
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-edit-reviews-db">
                        <i className="fas fa-edit mr-2"></i>Bulk Edit Reviews
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Categories Database Control */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-foreground flex items-center">
                        <i className="fas fa-tags mr-2 text-primary"></i>
                        Categories Table
                      </h4>
                      <Badge variant="secondary">{(categories as any[]).length} records</Badge>
                    </div>
                    <div className="space-y-3">
                      <Button className="w-full" data-testid="button-create-category-db">
                        <i className="fas fa-plus mr-2"></i>Create New Category
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-view-categories-db">
                        <i className="fas fa-eye mr-2"></i>View All Categories
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-edit-categories-db">
                        <i className="fas fa-edit mr-2"></i>Bulk Edit Categories
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Payments Database Control */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-foreground flex items-center">
                        <i className="fas fa-credit-card mr-2 text-primary"></i>
                        Payments Table
                      </h4>
                      <Badge variant="secondary">0 records</Badge>
                    </div>
                    <div className="space-y-3">
                      <Button className="w-full" data-testid="button-create-payment-db">
                        <i className="fas fa-plus mr-2"></i>Create New Payment
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-view-payments-db">
                        <i className="fas fa-eye mr-2"></i>View All Payments
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-edit-payments-db">
                        <i className="fas fa-edit mr-2"></i>Bulk Edit Payments
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Notifications Database Control */}
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-foreground flex items-center">
                        <i className="fas fa-bell mr-2 text-primary"></i>
                        Notifications Table
                      </h4>
                      <Badge variant="secondary">{(notifications as any[]).length} records</Badge>
                    </div>
                    <div className="space-y-3">
                      <Button className="w-full" data-testid="button-create-notification-db">
                        <i className="fas fa-plus mr-2"></i>Create New Notification
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-view-notifications-db">
                        <i className="fas fa-eye mr-2"></i>View All Notifications
                      </Button>
                      <Button variant="outline" className="w-full" data-testid="button-edit-notifications-db">
                        <i className="fas fa-edit mr-2"></i>Bulk Edit Notifications
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Advanced Database Operations */}
              <Card>
                <CardContent className="p-6">
                  <h4 className="font-semibold text-foreground mb-4 flex items-center">
                    <i className="fas fa-database mr-2 text-primary"></i>
                    Advanced Database Operations
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Button variant="outline" data-testid="button-backup-db">
                      <i className="fas fa-download mr-2"></i>Backup Database
                    </Button>
                    <Button variant="outline" data-testid="button-restore-db">
                      <i className="fas fa-upload mr-2"></i>Restore Database
                    </Button>
                    <Button variant="outline" data-testid="button-export-all-db">
                      <i className="fas fa-file-export mr-2"></i>Export All Data
                    </Button>
                    <Button variant="outline" data-testid="button-sql-query-db">
                      <i className="fas fa-terminal mr-2"></i>Run SQL Query
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* System Settings */}
          {activeTab === 'settings' && (
            <div className="mb-8">
              <h3 className="text-2xl font-semibold text-foreground mb-6">System Settings</h3>
              
              <Tabs defaultValue="general" className="w-full">
                <TabsList className="grid w-full grid-cols-5">
                  <TabsTrigger value="general">General</TabsTrigger>
                  <TabsTrigger value="payments">Payments</TabsTrigger>
                  <TabsTrigger value="security">Security</TabsTrigger>
                  <TabsTrigger value="notifications">Notifications</TabsTrigger>
                  <TabsTrigger value="integrations">Integrations</TabsTrigger>
                </TabsList>
                
                <TabsContent value="general" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h4 className="font-semibold text-foreground mb-4">Platform Configuration</h4>
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium text-foreground mb-2 block">Platform Name</label>
                            <Input defaultValue="primereview" data-testid="input-platform-name" />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-foreground mb-2 block">Admin Email</label>
                            <Input defaultValue="admin@primereview.com" data-testid="input-admin-email" />
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <label className="text-sm font-medium text-foreground mb-2 block">Min Review Amount</label>
                            <Input defaultValue="50" type="number" data-testid="input-min-amount" />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-foreground mb-2 block">Max Review Amount</label>
                            <Input defaultValue="150" type="number" data-testid="input-max-amount" />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-foreground mb-2 block">Platform Fee (%)</label>
                            <Input defaultValue="5" type="number" data-testid="input-platform-fee" />
                          </div>
                        </div>
                        <div className="pt-4">
                          <Button onClick={() => settingsMutation.mutate({ type: 'general' })} data-testid="button-save-general">
                            Save General Settings
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="payments" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h4 className="font-semibold text-foreground mb-4">Payment Configuration</h4>
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium text-foreground mb-2 block">Minimum Withdrawal</label>
                            <Input defaultValue="500" type="number" data-testid="input-min-withdrawal" />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-foreground mb-2 block">Processing Fee</label>
                            <Input defaultValue="10" type="number" data-testid="input-processing-fee" />
                          </div>
                        </div>
                        <div>
                          <h5 className="font-medium text-foreground mb-2">Enabled Payment Methods</h5>
                          <div className="space-y-2">
                            <div className="flex items-center space-x-2">
                              <input type="checkbox" id="upi" defaultChecked className="rounded" />
                              <label htmlFor="upi" className="text-sm text-foreground">UPI Payments</label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <input type="checkbox" id="bank" defaultChecked className="rounded" />
                              <label htmlFor="bank" className="text-sm text-foreground">Bank Transfer</label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <input type="checkbox" id="paypal" className="rounded" />
                              <label htmlFor="paypal" className="text-sm text-foreground">PayPal</label>
                            </div>
                          </div>
                        </div>
                        <div className="pt-4">
                          <Button onClick={() => settingsMutation.mutate({ type: 'payments' })} data-testid="button-save-payments">
                            Save Payment Settings
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="security" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h4 className="font-semibold text-foreground mb-4">Security Settings</h4>
                      <div className="space-y-6">
                        <div>
                          <h5 className="font-medium text-foreground mb-2">Authentication</h5>
                          <div className="space-y-2">
                            <div className="flex items-center space-x-2">
                              <input type="checkbox" id="2fa" defaultChecked className="rounded" />
                              <label htmlFor="2fa" className="text-sm text-foreground">Require 2FA for admin accounts</label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <input type="checkbox" id="session" defaultChecked className="rounded" />
                              <label htmlFor="session" className="text-sm text-foreground">Auto-logout inactive sessions</label>
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium text-foreground mb-2 block">Session Timeout (minutes)</label>
                            <Input defaultValue="30" type="number" data-testid="input-session-timeout" />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-foreground mb-2 block">Max Login Attempts</label>
                            <Input defaultValue="5" type="number" data-testid="input-max-attempts" />
                          </div>
                        </div>
                        <div className="pt-4">
                          <Button onClick={() => settingsMutation.mutate({ type: 'security' })} data-testid="button-save-security">
                            Save Security Settings
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="notifications" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h4 className="font-semibold text-foreground mb-4">Notification Settings</h4>
                      <div className="space-y-6">
                        <div>
                          <h5 className="font-medium text-foreground mb-2">Email Notifications</h5>
                          <div className="space-y-2">
                            <div className="flex items-center space-x-2">
                              <input type="checkbox" id="new-user" defaultChecked className="rounded" />
                              <label htmlFor="new-user" className="text-sm text-foreground">New user registrations</label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <input type="checkbox" id="new-review" defaultChecked className="rounded" />
                              <label htmlFor="new-review" className="text-sm text-foreground">New review submissions</label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <input type="checkbox" id="payment-issues" defaultChecked className="rounded" />
                              <label htmlFor="payment-issues" className="text-sm text-foreground">Payment issues</label>
                            </div>
                          </div>
                        </div>
                        <div className="pt-4">
                          <Button onClick={() => settingsMutation.mutate({ type: 'notifications' })} data-testid="button-save-notifications">
                            Save Notification Settings
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="integrations" className="mt-6">
                  <Card>
                    <CardContent className="p-6">
                      <h4 className="font-semibold text-foreground mb-4">Third-party Integrations</h4>
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="border border-border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h5 className="font-medium text-foreground">Email Service</h5>
                              <Badge variant="default">Connected</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-3">Send transactional emails</p>
                            <Button variant="outline" size="sm">Configure</Button>
                          </div>
                          <div className="border border-border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <h5 className="font-medium text-foreground">Analytics</h5>
                              <Badge variant="secondary">Not Connected</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-3">Track user behavior</p>
                            <Button variant="outline" size="sm">Connect</Button>
                          </div>
                        </div>
                        <div className="pt-4">
                          <Button onClick={() => settingsMutation.mutate({ type: 'integrations' })} data-testid="button-save-integrations">
                            Save Integration Settings
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
