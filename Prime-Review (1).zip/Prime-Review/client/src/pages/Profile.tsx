import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { useState } from "react";

export default function Profile() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditing, setIsEditing] = useState(false);

  const form = useForm({
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PUT", "/api/auth/profile", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Success",
        description: "Profile updated successfully!",
      });
      setIsEditing(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    updateProfileMutation.mutate(data);
  };

  const handleBackToHome = () => {
    window.location.href = '/';
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border bg-card shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-2xl font-bold text-foreground" data-testid="profile-title">Profile Settings</h1>
              <p className="text-muted-foreground">Manage your account information</p>
            </div>
            <Button
              onClick={handleBackToHome}
              variant="outline"
              className="flex items-center space-x-2"
              data-testid="button-home"
            >
              <i className="fas fa-home"></i>
              <span>Home</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="grid gap-6">
          {/* Profile Information Card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold text-foreground" data-testid="profile-info-title">Profile Information</h2>
                <Button
                  onClick={() => setIsEditing(!isEditing)}
                  variant="outline"
                  data-testid="button-edit-profile"
                >
                  {isEditing ? "Cancel" : "Edit"}
                </Button>
              </div>

              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      placeholder="Enter your first name"
                      disabled={!isEditing}
                      {...form.register("firstName")}
                      data-testid="input-first-name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      placeholder="Enter your last name"
                      disabled={!isEditing}
                      {...form.register("lastName")}
                      data-testid="input-last-name"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    disabled={true} // Email should not be editable
                    {...form.register("email")}
                    data-testid="input-email"
                  />
                  <p className="text-sm text-muted-foreground mt-1">
                    Email cannot be changed. Contact support if needed.
                  </p>
                </div>

                {isEditing && (
                  <div className="flex justify-end space-x-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsEditing(false)}
                      data-testid="button-cancel"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={updateProfileMutation.isPending}
                      data-testid="button-save-profile"
                    >
                      {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                    </Button>
                  </div>
                )}
              </form>
            </CardContent>
          </Card>

          {/* Account Information Card */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6" data-testid="account-info-title">Account Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label>User ID</Label>
                  <div className="mt-1 p-3 bg-muted rounded-md">
                    <p className="text-sm font-mono text-foreground" data-testid="user-id">{user?.id}</p>
                  </div>
                </div>
                <div>
                  <Label>Account Role</Label>
                  <div className="mt-1 p-3 bg-muted rounded-md">
                    <p className="text-sm font-medium text-foreground capitalize" data-testid="user-role">
                      {(user as any)?.role || 'User'}
                    </p>
                  </div>
                </div>
                <div>
                  <Label>Wallet Balance</Label>
                  <div className="mt-1 p-3 bg-muted rounded-md">
                    <p className="text-sm font-medium text-accent" data-testid="wallet-balance">
                      ₹{(user as any)?.walletBalance || '0'}
                    </p>
                  </div>
                </div>
                <div>
                  <Label>Member Since</Label>
                  <div className="mt-1 p-3 bg-muted rounded-md">
                    <p className="text-sm text-foreground" data-testid="member-since">
                      {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Picture Card */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6" data-testid="profile-picture-title">Profile Picture</h2>
              
              <div className="flex items-center space-x-6">
                <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center">
                  {user?.profileImageUrl ? (
                    <img
                      src={user.profileImageUrl}
                      alt="Profile"
                      className="w-20 h-20 rounded-full object-cover"
                      data-testid="profile-image"
                    />
                  ) : (
                    <i className="fas fa-user text-2xl text-muted-foreground" data-testid="default-avatar"></i>
                  )}
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-2">
                    Your profile picture is synced with your Replit account.
                  </p>
                  <Button variant="outline" size="sm" disabled data-testid="button-change-picture">
                    Change Picture (Coming Soon)
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}