import { useAuth } from "@/hooks/useAuth";
import Navigation from "@/components/Navigation";
import HeroSlider from "@/components/HeroSlider";
import AuthModal from "@/components/AuthModal";
import { useState } from "react";

export default function Landing() {
  const { isAuthenticated } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');

  const handleLogin = () => {
    window.location.href = '/api/login';
  };

  const handleSignup = () => {
    setAuthMode('signup');
    setShowAuthModal(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation 
        onLogin={handleLogin}
        onSignup={handleSignup}
        isAuthenticated={isAuthenticated}
      />
      
      <main className="min-h-screen">
        {/* Hero Section with Sliders */}
        <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 to-accent/5 py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <HeroSlider />
            
            {/* Stats Section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2" data-testid="stat-users">25K+</div>
                <div className="text-muted-foreground">Active Users</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-accent mb-2" data-testid="stat-earnings">₹2.5M+</div>
                <div className="text-muted-foreground">Paid to Reviewers</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2" data-testid="stat-brands">500+</div>
                <div className="text-muted-foreground">Partner Brands</div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-card">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-foreground mb-4">How primereview Works</h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">Our platform connects brands with authentic reviewers through a secure, transparent system.</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* For Brands */}
              <div className="bg-background p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-6">
                  <i className="fas fa-building text-primary text-2xl"></i>
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-foreground">For Brands</h3>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Create targeted campaigns</li>
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Set campaign duration & budget</li>
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Track performance metrics</li>
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Secure payment integration</li>
                </ul>
              </div>
              
              {/* For Users */}
              <div className="bg-background p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center mb-6">
                  <i className="fas fa-users text-accent text-2xl"></i>
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-foreground">For Reviewers</h3>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Browse available campaigns</li>
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Submit reviews with proof</li>
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Earn ₹50-₹150 per review</li>
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Instant wallet system</li>
                </ul>
              </div>
              
              {/* For Admin */}
              <div className="bg-background p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 bg-secondary/50 rounded-2xl flex items-center justify-center mb-6">
                  <i className="fas fa-shield-alt text-primary text-2xl"></i>
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-foreground">Quality Control</h3>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Review verification system</li>
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>User & brand management</li>
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Payment oversight</li>
                  <li className="flex items-center"><i className="fas fa-check text-accent mr-3"></i>Analytics dashboard</li>
                </ul>
              </div>
            </div>
          </div>
        </section>
      </main>

      <AuthModal 
        isOpen={showAuthModal}
        mode={authMode}
        onClose={() => setShowAuthModal(false)}
        onSwitchMode={(mode) => setAuthMode(mode)}
      />
    </div>
  );
}
