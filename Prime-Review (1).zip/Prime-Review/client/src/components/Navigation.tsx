import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";

interface NavigationProps {
  onLogin: () => void;
  onSignup: () => void;
  isAuthenticated: boolean;
}

export default function Navigation({ onLogin, onSignup, isAuthenticated }: NavigationProps) {
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.charAt(0) || ""}${lastName?.charAt(0) || ""}`.toUpperCase();
  };

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border backdrop-blur-sm">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-primary" data-testid="nav-logo">primereview</h1>
            </div>
            <div className="hidden md:block">
              <div className="flex items-baseline space-x-4">
                <a href="/" className="text-foreground hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium" data-testid="nav-home">Home</a>
                <a href="#features" className="text-muted-foreground hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium" data-testid="nav-features">Features</a>
                <a href="#pricing" className="text-muted-foreground hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium" data-testid="nav-pricing">Pricing</a>
                <a href="#contact" className="text-muted-foreground hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium" data-testid="nav-contact">Contact</a>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {!isAuthenticated ? (
              <>
                <Button
                  variant="ghost"
                  onClick={onLogin}
                  data-testid="button-login"
                >
                  Login
                </Button>
                <Button
                  onClick={onSignup}
                  data-testid="button-signup"
                >
                  Sign Up
                </Button>
              </>
            ) : (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full" data-testid="profile-menu-trigger">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={user?.profileImageUrl} alt={`${user?.firstName} ${user?.lastName}`} />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getInitials(user?.firstName, user?.lastName)}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none" data-testid="profile-name">
                        {user?.firstName} {user?.lastName}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground" data-testid="profile-email">
                        {user?.email}
                      </p>
                      {user?.role && (
                        <p className="text-xs leading-none text-muted-foreground capitalize" data-testid="profile-role">
                          Role: {user.role}
                        </p>
                      )}
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <a href="/profile" className="cursor-pointer" data-testid="profile-menu-profile">
                      <i className="fas fa-user mr-2 h-4 w-4"></i>
                      <span>Profile Settings</span>
                    </a>
                  </DropdownMenuItem>
                  {user?.walletBalance && (
                    <DropdownMenuItem asChild>
                      <div className="cursor-default" data-testid="profile-menu-wallet">
                        <i className="fas fa-wallet mr-2 h-4 w-4"></i>
                        <span>Wallet: ₹{user.walletBalance}</span>
                      </div>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-red-600" data-testid="profile-menu-logout">
                    <i className="fas fa-sign-out-alt mr-2 h-4 w-4"></i>
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
}
