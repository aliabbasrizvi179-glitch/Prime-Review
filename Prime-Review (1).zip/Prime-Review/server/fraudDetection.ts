import crypto from 'crypto';
import { fraudDetection, rateLimits, reviews } from '@shared/schema';
import { db } from './db';
import { eq, and, gte, sql } from 'drizzle-orm';

export class FraudDetectionService {
  
  // Generate hash for image content to detect duplicates
  static generateImageHash(imageBuffer: Buffer): string {
    return crypto.createHash('sha256').update(imageBuffer).digest('hex');
  }

  // Check for duplicate image submissions
  static async checkDuplicateImage(imageHash: string, campaignId: string, userId: string): Promise<boolean> {
    const [existingReview] = await db
      .select()
      .from(fraudDetection)
      .where(
        and(
          eq(fraudDetection.type, 'duplicate_image'),
          sql`metadata->>'imageHash' = ${imageHash}`,
          sql`metadata->>'campaignId' = ${campaignId}`
        )
      )
      .limit(1);

    if (existingReview) {
      // Log fraud attempt
      await db.insert(fraudDetection).values({
        userId,
        type: 'duplicate_image',
        description: `Duplicate image detected for campaign ${campaignId}`,
        metadata: { imageHash, campaignId, originalUserId: existingReview.userId },
        severity: 'high'
      });
      return true;
    }

    return false;
  }

  // Rate limiting for submissions
  static async checkRateLimit(identifier: string, action: string, maxAttempts: number = 10, windowMinutes: number = 60): Promise<{ allowed: boolean; remaining: number }> {
    const windowStart = new Date(Date.now() - (windowMinutes * 60 * 1000));

    // Get or create rate limit record
    const [existing] = await db
      .select()
      .from(rateLimits)
      .where(
        and(
          eq(rateLimits.identifier, identifier),
          eq(rateLimits.action, action),
          gte(rateLimits.windowStart, windowStart)
        )
      )
      .limit(1);

    if (existing) {
      if (existing.count >= maxAttempts) {
        return { allowed: false, remaining: 0 };
      }

      // Update count
      await db
        .update(rateLimits)
        .set({ 
          count: existing.count + 1,
          lastActivity: new Date()
        })
        .where(eq(rateLimits.id, existing.id));

      return { allowed: true, remaining: maxAttempts - existing.count - 1 };
    } else {
      // Create new rate limit record
      await db.insert(rateLimits).values({
        identifier,
        action,
        count: 1,
        windowStart: new Date(),
        lastActivity: new Date()
      });

      return { allowed: true, remaining: maxAttempts - 1 };
    }
  }

  // Validate image file
  static validateImage(file: any): { valid: boolean; error?: string } {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    const maxSize = 5 * 1024 * 1024; // 5MB
    const minWidth = 200;
    const minHeight = 200;

    if (!allowedTypes.includes(file.mimetype)) {
      return { valid: false, error: 'Invalid file type. Only JPEG, PNG, and WebP images are allowed.' };
    }

    if (file.size > maxSize) {
      return { valid: false, error: 'File size too large. Maximum size is 5MB.' };
    }

    // Additional checks can be added here for image dimensions
    // This would require image processing library like sharp

    return { valid: true };
  }

  // Detect suspicious activity patterns
  static async detectSuspiciousActivity(userId: string): Promise<void> {
    const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    // Check for too many submissions in 24 hours
    const [submissionCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(reviews)
      .where(
        and(
          eq(reviews.userId, userId),
          gte(reviews.submittedAt, last24Hours)
        )
      );

    if (submissionCount.count > 20) { // More than 20 submissions in 24 hours
      await db.insert(fraudDetection).values({
        userId,
        type: 'suspicious_activity',
        description: `Unusual submission frequency: ${submissionCount.count} submissions in 24 hours`,
        metadata: { submissionCount: submissionCount.count, timeframe: '24h' },
        severity: 'medium'
      });
    }
  }

  // Get device fingerprint from request headers
  static generateDeviceFingerprint(req: any): string {
    const userAgent = req.headers['user-agent'] || '';
    const acceptLanguage = req.headers['accept-language'] || '';
    const acceptEncoding = req.headers['accept-encoding'] || '';
    
    const fingerprint = `${userAgent}|${acceptLanguage}|${acceptEncoding}`;
    return crypto.createHash('md5').update(fingerprint).digest('hex');
  }

  // Get client IP address
  static getClientIP(req: any): string {
    return req.headers['x-forwarded-for'] || 
           req.headers['x-real-ip'] || 
           req.connection.remoteAddress || 
           req.socket.remoteAddress ||
           (req.connection.socket ? req.connection.socket.remoteAddress : null) ||
           req.ip || 
           'unknown';
  }
}