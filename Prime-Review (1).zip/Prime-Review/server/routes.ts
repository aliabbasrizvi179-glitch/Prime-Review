import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";
import { ObjectPermission } from "./objectAcl";
import { FraudDetectionService } from "./fraudDetection";
import { PaymentService } from "./paymentService";
import {
  insertCampaignSchema,
  insertReviewSchema,
  insertPaymentSchema,
  insertSliderSchema,
  insertNotificationSchema,
} from "@shared/schema";
import { z } from "zod";
import crypto from 'crypto';

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.put('/api/auth/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const { firstName, lastName } = req.body;
      
      // Validate the input
      if (!firstName && !lastName) {
        return res.status(400).json({ message: "At least one field (firstName or lastName) is required" });
      }
      
      const profileData: { firstName?: string; lastName?: string } = {};
      if (firstName !== undefined) profileData.firstName = firstName;
      if (lastName !== undefined) profileData.lastName = lastName;
      
      const updatedUser = await storage.updateUserProfile(userId, profileData);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.put('/api/auth/role', isAuthenticated, async (req: any, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const { role } = req.body;
      
      // Validate the role
      if (!role || !['user', 'brand'].includes(role)) {
        return res.status(400).json({ message: "Valid role (user or brand) is required" });
      }
      
      // Only allow setting role if user doesn't have one yet or has default role
      const currentUser = await storage.getUser(userId);
      if (!currentUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Allow role assignment for new users or users with default 'user' role
      if (currentUser.role && currentUser.role !== 'user' && currentUser.role !== role) {
        return res.status(400).json({ message: "Role can only be set once during initial signup" });
      }
      
      await storage.updateUserRole(userId, role as 'user' | 'brand');
      const updatedUser = await storage.getUser(userId);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Verification routes
  app.post('/api/verification/send-email', isAuthenticated, async (req: any, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const { email } = req.body;
      
      if (!email || !email.includes('@gmail.com')) {
        return res.status(400).json({ message: "Valid Gmail address is required" });
      }
      
      // Generate a 6-digit verification code
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      
      await storage.setEmailVerificationCode(userId, email, code);
      
      // For demo purposes, log the code (in production, send actual email)
      console.log(`Email verification code for ${email}: ${code}`);
      
      res.json({ 
        message: "Verification code sent to your email",
        // For demo purposes only - remove in production
        demo_code: code 
      });
    } catch (error) {
      console.error("Error sending email verification:", error);
      res.status(500).json({ message: "Failed to send verification code" });
    }
  });

  app.post('/api/verification/send-sms', isAuthenticated, async (req: any, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const { phone } = req.body;
      
      if (!phone || !/^\+?[\d\s-()]+$/.test(phone)) {
        return res.status(400).json({ message: "Valid phone number is required" });
      }
      
      // Generate a 6-digit verification code
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      
      await storage.setPhoneVerificationCode(userId, phone, code);
      
      // For demo purposes, log the code (in production, use Twilio SMS)
      console.log(`SMS verification code for ${phone}: ${code}`);
      
      res.json({ 
        message: "Verification code sent to your phone",
        // For demo purposes only - remove in production
        demo_code: code 
      });
    } catch (error) {
      console.error("Error sending SMS verification:", error);
      res.status(500).json({ message: "Failed to send verification code" });
    }
  });

  app.post('/api/verification/verify-email', isAuthenticated, async (req: any, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const { email, code } = req.body;
      
      if (!email || !code) {
        return res.status(400).json({ message: "Email and verification code are required" });
      }
      
      const isValid = await storage.verifyEmail(userId, email, code);
      
      if (isValid) {
        res.json({ message: "Email verified successfully" });
      } else {
        res.status(400).json({ message: "Invalid or expired verification code" });
      }
    } catch (error) {
      console.error("Error verifying email:", error);
      res.status(500).json({ message: "Failed to verify email" });
    }
  });

  app.post('/api/verification/verify-phone', isAuthenticated, async (req: any, res) => {
    try {
      const userId = (req.user as any).claims.sub;
      const { phone, code } = req.body;
      
      if (!phone || !code) {
        return res.status(400).json({ message: "Phone number and verification code are required" });
      }
      
      const isValid = await storage.verifyPhone(userId, phone, code);
      
      if (isValid) {
        res.json({ message: "Phone number verified successfully" });
      } else {
        res.status(400).json({ message: "Invalid or expired verification code" });
      }
    } catch (error) {
      console.error("Error verifying phone:", error);
      res.status(500).json({ message: "Failed to verify phone number" });
    }
  });

  // Object storage routes for file uploads
  app.get("/objects/:objectPath(*)", isAuthenticated, async (req, res) => {
    const userId = (req.user as any)?.claims?.sub;
    const objectStorageService = new ObjectStorageService();
    try {
      const objectFile = await objectStorageService.getObjectEntityFile(req.path);
      const canAccess = await objectStorageService.canAccessObjectEntity({
        objectFile,
        userId: userId,
        requestedPermission: ObjectPermission.READ,
      });
      if (!canAccess) {
        return res.sendStatus(401);
      }
      objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      console.error("Error checking object access:", error);
      if (error instanceof ObjectNotFoundError) {
        return res.sendStatus(404);
      }
      return res.sendStatus(500);
    }
  });

  app.post("/api/objects/upload", isAuthenticated, async (req, res) => {
    const objectStorageService = new ObjectStorageService();
    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    res.json({ uploadURL });
  });

  // Campaign routes
  app.get("/api/campaigns", async (req, res) => {
    try {
      const campaigns = await storage.getActiveCampaigns();
      res.json(campaigns);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.get("/api/campaigns/brand/:brandId", isAuthenticated, async (req, res) => {
    try {
      const brandId = req.params.brandId;
      const userId = (req.user as any)?.claims?.sub;
      
      // Ensure user can only access their own campaigns
      if (brandId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const campaigns = await storage.getCampaignsByBrand(brandId);
      res.json(campaigns);
    } catch (error) {
      console.error("Error fetching brand campaigns:", error);
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.post("/api/campaigns", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'brand') {
        return res.status(403).json({ message: "Only brands can create campaigns" });
      }
      
      const campaignData = insertCampaignSchema.parse({
        ...req.body,
        brandId: userId,
      });
      
      const campaign = await storage.createCampaign(campaignData);
      res.json(campaign);
    } catch (error) {
      console.error("Error creating campaign:", error);
      res.status(500).json({ message: "Failed to create campaign" });
    }
  });

  // Review routes
  app.get("/api/reviews/user/:userId", isAuthenticated, async (req, res) => {
    try {
      const userId = req.params.userId;
      const currentUserId = (req.user as any)?.claims?.sub;
      
      // Ensure user can only access their own reviews
      if (userId !== currentUserId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const reviews = await storage.getReviewsByUser(userId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching user reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.get("/api/reviews/pending", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const reviews = await storage.getPendingReviews();
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching pending reviews:", error);
      res.status(500).json({ message: "Failed to fetch pending reviews" });
    }
  });

  app.post("/api/reviews", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'user') {
        return res.status(403).json({ message: "Only users can submit reviews" });
      }

      // Anti-fraud measures
      const clientIP = FraudDetectionService.getClientIP(req);
      const deviceFingerprint = FraudDetectionService.generateDeviceFingerprint(req);

      // Rate limiting check
      const rateLimitResult = await FraudDetectionService.checkRateLimit(
        clientIP, 
        'review_submission', 
        10, // Max 10 submissions per hour
        60
      );

      if (!rateLimitResult.allowed) {
        return res.status(429).json({ 
          message: "Too many review submissions. Please try again later.",
          remainingAttempts: rateLimitResult.remaining
        });
      }

      // Check for duplicate image if proof images are provided
      const { proofImages, campaignId, ...otherData } = req.body;
      
      if (proofImages && proofImages.length > 0) {
        // For each proof image, check for duplicates
        for (const imageUrl of proofImages) {
          // Generate hash for the image URL (in real implementation, you'd get the actual image buffer)
          const imageHash = crypto.createHash('sha256').update(imageUrl).digest('hex');
          
          const isDuplicate = await FraudDetectionService.checkDuplicateImage(
            imageHash, 
            campaignId, 
            userId
          );

          if (isDuplicate) {
            return res.status(400).json({ 
              message: "Duplicate image detected. This image has already been submitted for this campaign." 
            });
          }
        }
      }

      // Detect suspicious activity patterns
      await FraudDetectionService.detectSuspiciousActivity(userId);

      const reviewData = insertReviewSchema.parse({
        ...otherData,
        userId,
        campaignId,
        proofImages,
        // Add anti-fraud fields
        imageHash: proofImages && proofImages.length > 0 ? 
          crypto.createHash('sha256').update(proofImages[0]).digest('hex') : null,
        ipAddress: clientIP,
        deviceFingerprint,
        submissionCount: 1
      });
      
      const review = await storage.createReview(reviewData);
      res.json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Failed to submit review" });
    }
  });

  app.put("/api/reviews/:id/status", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const { status, adminNotes } = req.body;
      const reviewId = req.params.id;
      
      await storage.updateReviewStatus(reviewId, status, adminNotes);
      
      // If approved, add reward to user wallet
      if (status === 'approved') {
        const review = await storage.getReview(reviewId);
        if (review) {
          const reviewer = await storage.getUser(review.userId);
          if (reviewer) {
            const newBalance = (parseFloat(reviewer.walletBalance || '0') + parseFloat(review.rewardAmount)).toString();
            await storage.updateUserWallet(review.userId, newBalance);
            
            // Create notification
            await storage.createNotification({
              userId: review.userId,
              title: "Review Approved!",
              message: `Your review has been approved. ₹${review.rewardAmount} has been added to your wallet.`,
              type: "review",
            });
          }
        }
      }
      
      res.json({ message: "Review status updated" });
    } catch (error) {
      console.error("Error updating review status:", error);
      res.status(500).json({ message: "Failed to update review status" });
    }
  });

  // Initialize payment service
  const paymentService = new PaymentService();

  // Payment routes
  app.get("/api/payments/user/:userId", isAuthenticated, async (req, res) => {
    try {
      const userId = req.params.userId;
      const currentUserId = (req.user as any)?.claims?.sub;
      
      // Ensure user can only access their own payments
      if (userId !== currentUserId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const payments = await storage.getPaymentsByUser(userId);
      res.json(payments);
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  app.post("/api/payments/withdraw", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      const { amount, paymentMethod, paymentDetails } = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const currentBalance = parseFloat(user.walletBalance || '0');
      const withdrawAmount = parseFloat(amount);
      
      if (withdrawAmount > currentBalance) {
        return res.status(400).json({ message: "Insufficient balance" });
      }
      
      if (withdrawAmount < 100) {
        return res.status(400).json({ message: "Minimum withdrawal amount is ₹100" });
      }

      // Process withdrawal through appropriate payment gateway
      let withdrawalResult;
      if (paymentMethod === 'upi') {
        withdrawalResult = await paymentService.processUPIWithdrawal(
          withdrawAmount,
          paymentDetails.upiId,
          userId
        );
      } else {
        // Default fallback processing
        withdrawalResult = { success: true, paymentId: `manual_${Date.now()}` };
      }

      if (!withdrawalResult.success) {
        return res.status(400).json({ message: withdrawalResult.error || "Withdrawal processing failed" });
      }
      
      const payment = await storage.createPayment({
        userId,
        type: 'withdrawal',
        amount,
        paymentMethod,
        paymentDetails,
        transactionId: withdrawalResult.paymentId,
      });
      
      // Update wallet balance
      const newBalance = (currentBalance - withdrawAmount).toString();
      await storage.updateUserWallet(userId, newBalance);
      
      res.json(payment);
    } catch (error) {
      console.error("Error processing withdrawal:", error);
      res.status(500).json({ message: "Failed to process withdrawal" });
    }
  });

  // Razorpay Payment Gateway Routes
  app.post("/api/payments/razorpay/create-order", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      const { amount, description } = req.body;

      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Valid amount is required" });
      }

      const receipt = paymentService.generateReceipt(userId, 'deposit');
      const amountInPaise = paymentService.formatAmountForRazorpay(amount);

      const order = await paymentService.createRazorpayOrder({
        amount: amountInPaise,
        currency: 'INR',
        receipt,
        notes: {
          userId,
          type: 'wallet_deposit',
          description: description || 'Wallet top-up'
        }
      });

      // Create payment record
      await storage.createPayment({
        userId,
        type: 'deposit',
        amount: amount.toString(),
        paymentMethod: 'razorpay',
        razorpayOrderId: order.id,
        paymentDetails: { orderId: order.id, amount, currency: 'INR' }
      });

      res.json({
        orderId: order.id,
        amount: order.amount,
        currency: order.currency,
        receipt: order.receipt
      });
    } catch (error) {
      console.error("Error creating Razorpay order:", error);
      res.status(500).json({ message: "Failed to create payment order" });
    }
  });

  app.post("/api/payments/razorpay/verify", isAuthenticated, async (req, res) => {
    try {
      const { orderId, paymentId, signature } = req.body;

      if (!orderId || !paymentId || !signature) {
        return res.status(400).json({ message: "Missing payment verification data" });
      }

      const isValid = paymentService.verifyRazorpayPayment(orderId, paymentId, signature);

      if (isValid) {
        // Update payment status and add funds to wallet
        const payments = await storage.getAllPayments();
        const payment = payments.find(p => p.razorpayOrderId === orderId);

        if (payment) {
          await storage.updatePaymentStatus(payment.id, 'completed');
          
          // Add funds to user wallet
          const user = await storage.getUser(payment.userId);
          if (user) {
            const newBalance = (parseFloat(user.walletBalance || '0') + parseFloat(payment.amount)).toString();
            await storage.updateUserWallet(payment.userId, newBalance);

            // Create notification
            await storage.createNotification({
              userId: payment.userId,
              title: "Payment Successful!",
              message: `₹${payment.amount} has been added to your wallet.`,
              type: "payment",
            });
          }

          res.json({ message: "Payment verified and funds added to wallet" });
        } else {
          res.status(404).json({ message: "Payment record not found" });
        }
      } else {
        res.status(400).json({ message: "Payment verification failed" });
      }
    } catch (error) {
      console.error("Error verifying Razorpay payment:", error);
      res.status(500).json({ message: "Payment verification failed" });
    }
  });

  // UPI Payment Routes
  app.post("/api/payments/upi/process", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      const { amount, upiId, description } = req.body;

      if (!amount || amount <= 0) {
        return res.status(400).json({ message: "Valid amount is required" });
      }

      if (!upiId) {
        return res.status(400).json({ message: "UPI ID is required" });
      }

      const paymentResult = await paymentService.processUPIPayment({
        amount,
        upiId,
        description: description || 'Wallet top-up',
        userId
      });

      if (paymentResult.success) {
        // Create payment record
        const payment = await storage.createPayment({
          userId,
          type: 'deposit',
          amount: amount.toString(),
          paymentMethod: 'upi',
          upiTransactionId: paymentResult.paymentId,
          paymentDetails: { upiId, amount, description }
        });

        res.json({
          transactionId: paymentResult.paymentId,
          orderId: paymentResult.orderId,
          message: "UPI payment initiated successfully"
        });
      } else {
        res.status(400).json({ message: paymentResult.error || "UPI payment failed" });
      }
    } catch (error) {
      console.error("Error processing UPI payment:", error);
      res.status(500).json({ message: "UPI payment processing failed" });
    }
  });

  // Payment Webhook Handlers
  app.post("/api/webhooks/razorpay", async (req, res) => {
    try {
      const signature = req.headers['x-razorpay-signature'] as string;
      const payload = JSON.stringify(req.body);

      if (!signature) {
        return res.status(400).json({ message: "Missing signature" });
      }

      const isValid = paymentService.verifyWebhookSignature(
        payload,
        signature,
        process.env.RAZORPAY_WEBHOOK_SECRET || ''
      );

      if (!isValid) {
        return res.status(400).json({ message: "Invalid signature" });
      }

      const { event, payload: eventPayload } = req.body;

      if (event === 'payment.captured') {
        const { order_id, id: payment_id, amount } = eventPayload.payment.entity;
        
        // Find and update payment record
        const payments = await storage.getAllPayments();
        const payment = payments.find(p => p.razorpayOrderId === order_id);

        if (payment) {
          await storage.updatePaymentStatus(payment.id, 'completed');
          
          // Add funds to wallet if not already done
          const user = await storage.getUser(payment.userId);
          if (user && payment.status === 'pending') {
            const newBalance = (parseFloat(user.walletBalance || '0') + parseFloat(payment.amount)).toString();
            await storage.updateUserWallet(payment.userId, newBalance);
          }
        }
      }

      res.json({ message: "Webhook processed successfully" });
    } catch (error) {
      console.error("Error processing Razorpay webhook:", error);
      res.status(500).json({ message: "Webhook processing failed" });
    }
  });

  app.post("/api/webhooks/upi", async (req, res) => {
    try {
      const signature = req.headers['x-upi-signature'] as string;
      const payload = JSON.stringify(req.body);

      if (!signature) {
        return res.status(400).json({ message: "Missing signature" });
      }

      const isValid = paymentService.verifyWebhookSignature(
        payload,
        signature,
        process.env.UPI_WEBHOOK_SECRET || ''
      );

      if (!isValid) {
        return res.status(400).json({ message: "Invalid signature" });
      }

      const { event, data } = req.body;

      if (event === 'payment.success') {
        const { transaction_id, amount } = data;
        
        // Find and update payment record
        const payments = await storage.getAllPayments();
        const payment = payments.find(p => p.upiTransactionId === transaction_id);

        if (payment) {
          await storage.updatePaymentStatus(payment.id, 'completed');
          
          // Add funds to wallet
          const user = await storage.getUser(payment.userId);
          if (user) {
            const newBalance = (parseFloat(user.walletBalance || '0') + parseFloat(payment.amount)).toString();
            await storage.updateUserWallet(payment.userId, newBalance);

            // Create notification
            await storage.createNotification({
              userId: payment.userId,
              title: "UPI Payment Successful!",
              message: `₹${payment.amount} has been added to your wallet via UPI.`,
              type: "payment",
            });
          }
        }
      }

      res.json({ message: "UPI webhook processed successfully" });
    } catch (error) {
      console.error("Error processing UPI webhook:", error);
      res.status(500).json({ message: "UPI webhook processing failed" });
    }
  });

  // Referral routes
  app.get("/api/referrals/my-code", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Generate referral code if user doesn't have one
      let referralCode = user.referralCode;
      if (!referralCode) {
        referralCode = await storage.generateReferralCode(userId);
      }
      
      res.json({ referralCode });
    } catch (error) {
      console.error("Error fetching referral code:", error);
      res.status(500).json({ message: "Failed to fetch referral code" });
    }
  });

  app.get("/api/referrals/stats", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      const stats = await storage.getReferralStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching referral stats:", error);
      res.status(500).json({ message: "Failed to fetch referral stats" });
    }
  });

  app.get("/api/referrals/history", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.claims?.sub;
      const referrals = await storage.getReferralsByUser(userId);
      res.json(referrals);
    } catch (error) {
      console.error("Error fetching referral history:", error);
      res.status(500).json({ message: "Failed to fetch referral history" });
    }
  });

  app.post("/api/referrals/validate", async (req, res) => {
    try {
      const { code } = req.body;
      
      if (!code) {
        return res.status(400).json({ message: "Referral code is required" });
      }
      
      const referrer = await storage.validateReferralCode(code);
      
      if (!referrer) {
        return res.status(404).json({ message: "Invalid referral code" });
      }
      
      res.json({ 
        valid: true, 
        referrerName: `${referrer.firstName} ${referrer.lastName}`,
        referrerId: referrer.id 
      });
    } catch (error) {
      console.error("Error validating referral code:", error);
      res.status(500).json({ message: "Failed to validate referral code" });
    }
  });

  app.post("/api/referrals/register", isAuthenticated, async (req, res) => {
    try {
      const { referralCode } = req.body;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!referralCode) {
        return res.status(400).json({ message: "Referral code is required" });
      }
      
      // Validate referral code
      const referrer = await storage.validateReferralCode(referralCode);
      if (!referrer) {
        return res.status(404).json({ message: "Invalid referral code" });
      }
      
      // Prevent self-referral
      if (referrer.id === userId) {
        return res.status(400).json({ message: "You cannot refer yourself" });
      }
      
      // Update user's referredBy field
      const user = await storage.getUser(userId);
      if (user?.referredBy) {
        return res.status(400).json({ message: "You have already been referred" });
      }
      
      // Set user as referred
      await storage.updateUserWallet(userId, user?.walletBalance || '0'); // This will trigger the referredBy update via upsert
      
      // Create referral record with reward
      const settings = await storage.getSystemSettings();
      const rewardAmount = settings?.referralReward || 25;
      
      const referral = await storage.createReferral({
        referrerId: referrer.id,
        referredId: userId,
        referralCode,
        rewardAmount: rewardAmount.toString(),
        isPaid: false,
      });
      
      // Auto-process referral reward
      await storage.processReferralReward(referral.id);
      
      // Create notification for referrer
      await storage.createNotification({
        userId: referrer.id,
        title: "New Referral Reward!",
        message: `You earned ₹${rewardAmount} for referring a new user!`,
        type: "referral",
      });
      
      res.json({ message: "Referral registered successfully", reward: rewardAmount });
    } catch (error) {
      console.error("Error registering referral:", error);
      res.status(500).json({ message: "Failed to register referral" });
    }
  });

  // Category routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post("/api/categories", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const { name, description, minPrice, maxPrice } = req.body;
      const category = await storage.createCategory(name, description, minPrice, maxPrice);
      res.json(category);
    } catch (error) {
      console.error("Error creating category:", error);
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  // Slider routes
  app.get("/api/sliders", async (req, res) => {
    try {
      const sliders = await storage.getSliders();
      res.json(sliders);
    } catch (error) {
      console.error("Error fetching sliders:", error);
      res.status(500).json({ message: "Failed to fetch sliders" });
    }
  });

  app.put("/api/sliders/:id", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const sliderId = req.params.id;
      const sliderData = insertSliderSchema.parse(req.body);
      
      await storage.updateSlider(sliderId, sliderData);
      res.json({ message: "Slider updated successfully" });
    } catch (error) {
      console.error("Error updating slider:", error);
      res.status(500).json({ message: "Failed to update slider" });
    }
  });

  // Notification routes
  app.get("/api/notifications/user/:userId", isAuthenticated, async (req, res) => {
    try {
      const userId = req.params.userId;
      const currentUserId = (req.user as any)?.claims?.sub;
      
      // Ensure user can only access their own notifications
      if (userId !== currentUserId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const notifications = await storage.getNotificationsByUser(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.put("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    try {
      const notificationId = req.params.id;
      await storage.markNotificationRead(notificationId);
      res.json({ message: "Notification marked as read" });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  app.get("/api/admin/users", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.put("/api/admin/users/:id/status", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const userId = req.params.id;
      const { status } = req.body;
      
      await storage.updateUserStatus(userId, status);
      res.json({ message: "User status updated" });
    } catch (error) {
      console.error("Error updating user status:", error);
      res.status(500).json({ message: "Failed to update user status" });
    }
  });

  // Enhanced admin user management
  app.put("/api/admin/users/:userId", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const { userId } = req.params;
      const { action, role, status } = req.body;
      
      switch (action) {
        case 'updateRole':
          await storage.updateUserRole(userId, role);
          break;
        case 'suspend':
          await storage.updateUserStatus(userId, 'suspended');
          break;
        case 'activate':
          await storage.updateUserStatus(userId, 'active');
          break;
        default:
          return res.status(400).json({ message: "Invalid action" });
      }
      
      res.json({ message: "User updated successfully" });
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // Admin brand management routes
  app.get("/api/admin/brands", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const brands = await storage.getAllBrands();
      res.json(brands);
    } catch (error) {
      console.error("Error fetching all brands:", error);
      res.status(500).json({ message: "Failed to fetch brands" });
    }
  });

  app.put("/api/admin/brands/:brandId", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const { brandId } = req.params;
      const { action } = req.body;
      
      switch (action) {
        case 'approve':
          await storage.updateUserStatus(brandId, 'approved');
          break;
        case 'reject':
          await storage.updateUserStatus(brandId, 'rejected');
          break;
        case 'suspend':
          await storage.updateUserStatus(brandId, 'suspended');
          break;
        default:
          return res.status(400).json({ message: "Invalid action" });
      }
      
      res.json({ message: "Brand updated successfully" });
    } catch (error) {
      console.error("Error updating brand:", error);
      res.status(500).json({ message: "Failed to update brand" });
    }
  });

  // Admin campaign oversight routes
  app.get("/api/admin/campaigns", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const campaigns = await storage.getAllCampaigns();
      res.json(campaigns);
    } catch (error) {
      console.error("Error fetching all campaigns:", error);
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.put("/api/admin/campaigns/:campaignId", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const { campaignId } = req.params;
      const { action } = req.body;
      
      switch (action) {
        case 'suspend':
          await storage.updateCampaignStatus(campaignId, 'suspended');
          break;
        case 'activate':
          await storage.updateCampaignStatus(campaignId, 'active');
          break;
        default:
          return res.status(400).json({ message: "Invalid action" });
      }
      
      res.json({ message: "Campaign updated successfully" });
    } catch (error) {
      console.error("Error updating campaign:", error);
      res.status(500).json({ message: "Failed to update campaign" });
    }
  });

  // Admin payment management routes
  app.get("/api/admin/payments", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const payments = await storage.getAllPayments();
      res.json(payments);
    } catch (error) {
      console.error("Error fetching all payments:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  // Admin system settings routes
  app.get("/api/admin/settings", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const settings = await storage.getSystemSettings();
      res.json(settings || {});
    } catch (error) {
      console.error("Error fetching system settings:", error);
      res.status(500).json({ message: "Failed to fetch system settings" });
    }
  });

  app.put("/api/admin/settings", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser((req.user as any)?.claims?.sub);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }
      
      const { type, ...settings } = req.body;
      
      await storage.updateSystemSettings(type, settings);
      res.json({ message: "Settings updated successfully" });
    } catch (error) {
      console.error("Error updating system settings:", error);
      res.status(500).json({ message: "Failed to update system settings" });
    }
  });

  // Handle file upload completion
  app.put("/api/review-images", isAuthenticated, async (req, res) => {
    if (!req.body.imageURL) {
      return res.status(400).json({ error: "imageURL is required" });
    }

    const userId = (req.user as any)?.claims?.sub;

    try {
      const objectStorageService = new ObjectStorageService();
      const objectPath = await objectStorageService.trySetObjectEntityAclPolicy(
        req.body.imageURL,
        {
          owner: userId,
          visibility: "private", // Review images should be private
        },
      );

      res.status(200).json({
        objectPath: objectPath,
      });
    } catch (error) {
      console.error("Error setting review image:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
