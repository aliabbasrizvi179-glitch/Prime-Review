import { useState, useEffect } from 'react';
import { apiClient } from '@/lib/api';

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: string;
}

export function useAuth() {
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem('admin_token');
      if (!token) {
        setIsLoading(false);
        return;
      }

      const response = await apiClient.verifyToken();
      if (response.success && response.data) {
        setAdmin(response.data.admin);
        setIsAuthenticated(true);
      } else {
        localStorage.removeItem('admin_token');
        setIsAuthenticated(false);
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      localStorage.removeItem('admin_token');
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem('admin_token');
    setAdmin(null);
    setIsAuthenticated(false);
    window.location.reload();
  };

  useEffect(() => {
    checkAuth();
  }, []);

  return {
    admin,
    isLoading,
    isAuthenticated,
    logout,
    checkAuth
  };
}