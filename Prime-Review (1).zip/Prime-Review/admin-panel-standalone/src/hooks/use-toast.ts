import { useState } from "react"

export interface Toast {
  title: string
  description?: string
  variant?: "default" | "destructive"
}

export function useToast() {
  const [toasts, setToasts] = useState<Toast[]>([])

  const toast = (toast: Toast) => {
    setToasts(prev => [...prev, toast])
    // Simple implementation - just show alert
    alert(`${toast.title}: ${toast.description || ''}`)
  }

  return { toast, toasts }
}