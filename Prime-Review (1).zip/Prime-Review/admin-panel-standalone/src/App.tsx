import { QueryClientProvider } from '@tanstack/react-query'
import { Switch, Route } from 'wouter'
import AdminDashboard from './pages/AdminDashboard'
import LoginForm from './components/LoginForm'
import { queryClient } from './lib/queryClient'
import { useAuth } from './hooks/useAuth'
import { Toaster } from './components/ui/toaster'

function AppContent() {
  const { isAuthenticated, isLoading, checkAuth } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-3xl text-blue-600 mb-4"></i>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginForm onLoginSuccess={() => checkAuth()} />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Switch>
        <Route path="/" component={AdminDashboard} />
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/dashboard" component={AdminDashboard} />
        <Route>
          <div className="min-h-screen flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">404 - Page Not Found</h1>
              <a href="/" className="text-blue-600 hover:text-blue-800">Return to Dashboard</a>
            </div>
          </div>
        </Route>
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppContent />
      <Toaster />
    </QueryClientProvider>
  )
}

export default App