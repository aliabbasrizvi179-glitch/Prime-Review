const API_BASE = '/api';

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  errors?: any[];
}

class ApiClient {
  private baseURL: string;
  private token: string | null;

  constructor() {
    this.baseURL = API_BASE;
    this.token = localStorage.getItem('admin_token');
  }

  private getHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    return headers;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const url = `${this.baseURL}${endpoint}`;
    
    const response = await fetch(url, {
      ...options,
      headers: {
        ...this.getHeaders(),
        ...options.headers,
      },
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || `HTTP error! status: ${response.status}`);
    }

    return data;
  }

  setToken(token: string) {
    this.token = token;
    localStorage.setItem('admin_token', token);
  }

  clearToken() {
    this.token = null;
    localStorage.removeItem('admin_token');
  }

  // Authentication
  async login(email: string, password: string) {
    const response = await this.request<{ token: string; admin: any }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    if (response.success && response.data) {
      this.setToken(response.data.token);
    }

    return response;
  }

  async verifyToken() {
    return this.request<{ admin: any }>('/auth/verify');
  }

  async changePassword(currentPassword: string, newPassword: string) {
    return this.request('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword }),
    });
  }

  // Dashboard
  async getDashboardStats() {
    return this.request<any>('/admin/dashboard/stats');
  }

  // Users
  async getUsers(params: any = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request<any>(`/admin/users${query ? `?${query}` : ''}`);
  }

  async createUser(userData: any) {
    return this.request('/admin/users', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async updateUserStatus(userId: string, status: string) {
    return this.request(`/admin/users/${userId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  }

  // Reviews
  async getReviews(params: any = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request<any>(`/admin/reviews${query ? `?${query}` : ''}`);
  }

  async updateReviewStatus(reviewId: string, status: string, adminNotes?: string) {
    return this.request(`/admin/reviews/${reviewId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, adminNotes }),
    });
  }

  // Payments
  async getPayments(params: any = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request<any>(`/admin/payments${query ? `?${query}` : ''}`);
  }

  // Content Management
  async getBanners() {
    return this.request<any[]>('/admin/banners');
  }

  async createBanner(formData: FormData) {
    const headers: Record<string, string> = {};
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(`${this.baseURL}/admin/banners`, {
      method: 'POST',
      headers,
      body: formData,
    });

    return response.json();
  }

  async getNotifications() {
    return this.request<any[]>('/admin/notifications');
  }

  async createNotification(notificationData: any) {
    return this.request('/admin/notifications', {
      method: 'POST',
      body: JSON.stringify(notificationData),
    });
  }

  // Settings
  async getSettings() {
    return this.request<any>('/admin/settings');
  }

  async updateSettings(settings: any) {
    return this.request('/admin/settings', {
      method: 'POST',
      body: JSON.stringify(settings),
    });
  }

  // API Keys
  async getApiKeys() {
    return this.request<any[]>('/admin/api-keys');
  }

  async saveApiKey(keyData: any) {
    return this.request('/admin/api-keys', {
      method: 'POST',
      body: JSON.stringify(keyData),
    });
  }

  // Database
  async backupDatabase() {
    return this.request<any>('/admin/database/backup');
  }
}

export const apiClient = new ApiClient();