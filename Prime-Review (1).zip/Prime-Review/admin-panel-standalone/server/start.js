#!/usr/bin/env node

const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

console.log('🚀 Starting Secure Admin Panel...\n');

// Check if node_modules exists
const nodeModulesPath = path.join(__dirname, '..', 'node_modules');
if (!fs.existsSync(nodeModulesPath)) {
  console.log('📦 Installing dependencies...');
  exec('npm install', { cwd: path.join(__dirname, '..') }, (error, stdout, stderr) => {
    if (error) {
      console.error('❌ Failed to install dependencies:', error);
      process.exit(1);
    }
    console.log('✅ Dependencies installed successfully\n');
    startServer();
  });
} else {
  startServer();
}

function startServer() {
  console.log('🔧 Initializing database and starting server...');
  
  // Start the main server
  const server = exec('node server/index.js', { cwd: path.join(__dirname, '..') });
  
  server.stdout.on('data', (data) => {
    console.log(data.toString());
  });
  
  server.stderr.on('data', (data) => {
    console.error(data.toString());
  });
  
  server.on('close', (code) => {
    console.log(`\n🔴 Server process exited with code ${code}`);
    process.exit(code);
  });
  
  // Handle termination gracefully
  process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down server...');
    server.kill('SIGTERM');
  });
  
  process.on('SIGTERM', () => {
    console.log('\n🛑 Shutting down server...');
    server.kill('SIGTERM');
  });
}