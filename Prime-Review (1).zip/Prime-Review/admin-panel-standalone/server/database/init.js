const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, '../../database/admin_panel.db');

let db;

// Initialize database connection
function initDatabase() {
  return new Promise((resolve, reject) => {
    db = new sqlite3.Database(DB_PATH, (err) => {
      if (err) {
        console.error('Error opening database:', err);
        reject(err);
      } else {
        console.log('✅ Connected to SQLite database');
        createTables().then(resolve).catch(reject);
      }
    });
  });
}

// Create all necessary tables
function createTables() {
  return new Promise((resolve, reject) => {
    const tables = [
      // Admin users table
      `CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        role TEXT DEFAULT 'admin',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME,
        is_active BOOLEAN DEFAULT 1
      )`,
      
      // Users table
      `CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        status TEXT DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME,
        wallet_balance DECIMAL(10,2) DEFAULT 0,
        total_earnings DECIMAL(10,2) DEFAULT 0,
        reviews_count INTEGER DEFAULT 0
      )`,
      
      // Brands table
      `CREATE TABLE IF NOT EXISTS brands (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        website TEXT,
        description TEXT,
        status TEXT DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        total_campaigns INTEGER DEFAULT 0,
        total_spent DECIMAL(10,2) DEFAULT 0
      )`,
      
      // Reviews table
      `CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        campaign_id INTEGER,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        rating INTEGER NOT NULL,
        status TEXT DEFAULT 'pending',
        reward_amount DECIMAL(10,2) NOT NULL,
        screenshot_url TEXT,
        admin_notes TEXT,
        submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        reviewed_at DATETIME,
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`,
      
      // Campaigns table
      `CREATE TABLE IF NOT EXISTS campaigns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        brand_id INTEGER,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        target_url TEXT NOT NULL,
        reward_per_review DECIMAL(10,2) NOT NULL,
        total_budget DECIMAL(10,2) NOT NULL,
        spent_amount DECIMAL(10,2) DEFAULT 0,
        required_reviews INTEGER NOT NULL,
        completed_reviews INTEGER DEFAULT 0,
        status TEXT DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        ends_at DATETIME,
        FOREIGN KEY (brand_id) REFERENCES brands(id)
      )`,
      
      // Payments table
      `CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        amount DECIMAL(10,2) NOT NULL,
        type TEXT NOT NULL, -- 'payout', 'reward'
        status TEXT DEFAULT 'pending',
        payment_method TEXT,
        transaction_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        processed_at DATETIME,
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`,
      
      // Notifications table
      `CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        type TEXT DEFAULT 'info', -- 'info', 'warning', 'success', 'error'
        target_users TEXT DEFAULT 'all', -- 'all', 'users', 'brands'
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // Banners table
      `CREATE TABLE IF NOT EXISTS banners (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        image_url TEXT NOT NULL,
        link_url TEXT,
        position TEXT DEFAULT 'home', -- 'home', 'dashboard'
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        display_order INTEGER DEFAULT 0
      )`,
      
      // Settings table
      `CREATE TABLE IF NOT EXISTS settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT UNIQUE NOT NULL,
        value TEXT,
        type TEXT DEFAULT 'string', -- 'string', 'number', 'boolean', 'json'
        description TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // API Keys table
      `CREATE TABLE IF NOT EXISTS api_keys (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        service_name TEXT NOT NULL,
        key_name TEXT NOT NULL,
        key_value TEXT NOT NULL,
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    let completed = 0;
    const total = tables.length;

    tables.forEach((sql) => {
      db.run(sql, (err) => {
        if (err) {
          console.error('Error creating table:', err);
          reject(err);
        } else {
          completed++;
          if (completed === total) {
            console.log('✅ Database tables created successfully');
            insertDefaultData().then(resolve).catch(reject);
          }
        }
      });
    });
  });
}

// Insert default settings and create default admin
async function insertDefaultData() {
  return new Promise(async (resolve, reject) => {
    try {
      // Default settings
      const defaultSettings = [
        { key: 'site_name', value: 'PrimeReview Admin', description: 'Site name' },
        { key: 'site_logo', value: '/images/logo.png', description: 'Site logo URL' },
        { key: 'primary_color', value: '#3b82f6', description: 'Primary theme color' },
        { key: 'min_review_price', value: '50', type: 'number', description: 'Minimum review price in rupees' },
        { key: 'max_review_price', value: '150', type: 'number', description: 'Maximum review price in rupees' },
        { key: 'payout_threshold', value: '500', type: 'number', description: 'Minimum payout amount' },
        { key: 'email_notifications', value: 'true', type: 'boolean', description: 'Enable email notifications' },
        { key: 'auto_approve_reviews', value: 'false', type: 'boolean', description: 'Auto approve reviews' }
      ];

      // Insert settings
      for (const setting of defaultSettings) {
        await new Promise((resolve, reject) => {
          db.run(
            'INSERT OR IGNORE INTO settings (key, value, type, description) VALUES (?, ?, ?, ?)',
            [setting.key, setting.value, setting.type || 'string', setting.description],
            (err) => err ? reject(err) : resolve()
          );
        });
      }

      // Create default admin user
      const defaultAdmin = {
        email: 'admin@admin.com',
        password: await bcrypt.hash('admin123', 12),
        name: 'System Administrator'
      };

      db.run(
        'INSERT OR IGNORE INTO admins (email, password, name) VALUES (?, ?, ?)',
        [defaultAdmin.email, defaultAdmin.password, defaultAdmin.name],
        (err) => {
          if (err) {
            reject(err);
          } else {
            console.log('✅ Default admin user created: admin@admin.com / admin123');
            resolve();
          }
        }
      );
    } catch (error) {
      reject(error);
    }
  });
}

// Get database instance
function getDatabase() {
  return db;
}

module.exports = {
  initDatabase,
  getDatabase
};