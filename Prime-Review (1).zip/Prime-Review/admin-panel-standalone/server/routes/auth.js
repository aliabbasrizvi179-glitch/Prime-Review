const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { getDatabase } = require('../database/init');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const JWT_EXPIRY = '24h';

// Login endpoint
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 })
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false, 
        message: 'Invalid input data',
        errors: errors.array() 
      });
    }

    const { email, password } = req.body;
    const db = getDatabase();

    // Find admin user
    db.get(
      'SELECT * FROM admins WHERE email = ? AND is_active = 1',
      [email],
      async (err, admin) => {
        if (err) {
          console.error('Database error:', err);
          return res.status(500).json({ 
            success: false, 
            message: 'Server error' 
          });
        }

        if (!admin) {
          return res.status(401).json({ 
            success: false, 
            message: 'Invalid credentials' 
          });
        }

        // Verify password
        const isValidPassword = await bcrypt.compare(password, admin.password);
        if (!isValidPassword) {
          return res.status(401).json({ 
            success: false, 
            message: 'Invalid credentials' 
          });
        }

        // Update last login
        db.run(
          'UPDATE admins SET last_login = CURRENT_TIMESTAMP WHERE id = ?',
          [admin.id]
        );

        // Generate JWT token
        const token = jwt.sign(
          { 
            id: admin.id, 
            email: admin.email, 
            role: admin.role 
          },
          JWT_SECRET,
          { expiresIn: JWT_EXPIRY }
        );

        res.json({
          success: true,
          message: 'Login successful',
          token,
          admin: {
            id: admin.id,
            email: admin.email,
            name: admin.name,
            role: admin.role
          }
        });
      }
    );
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Server error' 
    });
  }
});

// Verify token endpoint
router.get('/verify', async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ 
        success: false, 
        message: 'No token provided' 
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const db = getDatabase();

    // Get current admin data
    db.get(
      'SELECT id, email, name, role FROM admins WHERE id = ? AND is_active = 1',
      [decoded.id],
      (err, admin) => {
        if (err || !admin) {
          return res.status(401).json({ 
            success: false, 
            message: 'Invalid token' 
          });
        }

        res.json({
          success: true,
          admin
        });
      }
    );
  } catch (error) {
    res.status(401).json({ 
      success: false, 
      message: 'Invalid token' 
    });
  }
});

// Change password endpoint
router.post('/change-password', [
  body('currentPassword').isLength({ min: 6 }),
  body('newPassword').isLength({ min: 6 })
], async (req, res) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ 
        success: false, 
        message: 'Unauthorized' 
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const { currentPassword, newPassword } = req.body;
    const db = getDatabase();

    // Get current admin
    db.get(
      'SELECT * FROM admins WHERE id = ?',
      [decoded.id],
      async (err, admin) => {
        if (err || !admin) {
          return res.status(404).json({ 
            success: false, 
            message: 'Admin not found' 
          });
        }

        // Verify current password
        const isValidPassword = await bcrypt.compare(currentPassword, admin.password);
        if (!isValidPassword) {
          return res.status(400).json({ 
            success: false, 
            message: 'Current password is incorrect' 
          });
        }

        // Hash new password
        const hashedNewPassword = await bcrypt.hash(newPassword, 12);

        // Update password
        db.run(
          'UPDATE admins SET password = ? WHERE id = ?',
          [hashedNewPassword, admin.id],
          (err) => {
            if (err) {
              return res.status(500).json({ 
                success: false, 
                message: 'Failed to update password' 
              });
            }

            res.json({
              success: true,
              message: 'Password updated successfully'
            });
          }
        );
      }
    );
  } catch (error) {
    res.status(401).json({ 
      success: false, 
      message: 'Unauthorized' 
    });
  }
});

module.exports = router;