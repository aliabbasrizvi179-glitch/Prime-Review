const jwt = require('jsonwebtoken');
const { getDatabase } = require('../database/init');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Middleware to verify admin authentication
const authenticateAdmin = (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ 
        success: false, 
        message: 'Access denied. No token provided.' 
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    const db = getDatabase();

    // Verify admin exists and is active
    db.get(
      'SELECT id, email, name, role FROM admins WHERE id = ? AND is_active = 1',
      [decoded.id],
      (err, admin) => {
        if (err || !admin) {
          return res.status(401).json({ 
            success: false, 
            message: 'Invalid token or admin not found.' 
          });
        }

        req.admin = admin;
        next();
      }
    );
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(401).json({ 
      success: false, 
      message: 'Invalid token.' 
    });
  }
};

// Middleware to check specific admin role
const requireRole = (role) => {
  return (req, res, next) => {
    if (req.admin && req.admin.role === role) {
      next();
    } else {
      res.status(403).json({ 
        success: false, 
        message: 'Access denied. Insufficient permissions.' 
      });
    }
  };
};

module.exports = {
  authenticateAdmin,
  requireRole
};