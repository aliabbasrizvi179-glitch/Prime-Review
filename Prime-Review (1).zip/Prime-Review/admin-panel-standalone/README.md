# Secure Admin Panel

A comprehensive admin panel web application with authentication, dashboard analytics, user/review/payment/content management, and system settings.

## Features

- **Dashboard Overview** - Key metrics and statistics
- **User Management** - View and manage all users
- **Brand Management** - Handle brand accounts and approvals
- **Campaign Oversight** - Monitor all review campaigns
- **Review Approval** - Approve/reject submitted reviews
- **Payment Management** - Handle payments and withdrawals
- **Analytics** - Platform performance insights
- **Database Control** - Direct database management tools
- **System Settings** - Platform configuration

## Installation

1. Extract the zip file
2. Install dependencies:
   ```bash
   npm install
   ```

3. Configure environment variables:
   ```bash
   # Create .env file
   VITE_API_URL=http://your-api-server:5000
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

## Deployment

### Build for Production
```bash
npm run build
```

### Preview Production Build
```bash
npm run preview
```

## Configuration

### API Connection
Set the `VITE_API_URL` environment variable to point to your main PrimeReview API server:
- Development: `http://localhost:5000`
- Production: `https://your-api-domain.com`

### Port Configuration
The admin panel runs on port 3001 by default. To change:
1. Edit `vite.config.ts`
2. Update the server port setting

## Features Overview

### Database Control Panel
- Direct CRUD operations on all database tables
- Bulk operations for users, campaigns, reviews
- Database backup, restore, and export capabilities
- SQL query execution interface

### Admin Capabilities
- Create and manage users, brands, campaigns
- Review approval workflow
- Payment processing oversight
- System analytics and reporting

## Security Notes

- Ensure proper authentication before deploying
- Use HTTPS in production
- Restrict access to authorized admin users only
- Regular security updates recommended

## Support

For technical support or feature requests, contact the development team.